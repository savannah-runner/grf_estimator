#include <iostream>
#include <raisim/World.hpp>
#include <yaml-cpp/yaml.h>
#include "raisim/RaisimServer.hpp"
#include <fstream>
#include <vector>
#include <iomanip>
#include <memory>

Eigen::Vector4d quaternionFromDirectionVector(Eigen::Vector3d vec){
    std::cout.precision(4);
    double norm = vec.norm();
    if (norm<1e-6){
        return Eigen::Vector4d{1,0,0,0};
    }
    Eigen::Vector3d direction = vec/norm;
    double thetaZ = atan2(direction(1),direction(0))+M_PI/2; //x를 회전축에 맞추기
    double thetaX = acos(direction(2)); //z축 기울이기
    raisim::Vec<3> eulerAngle = raisim::Vec<3>{thetaX,0,thetaZ};
    raisim::Mat<3,3> rot;
    raisim::Vec<4> quat;
    raisim::rpyToRotMat_intrinsic(eulerAngle,rot);
    raisim::rotMatToQuat(rot,quat);
    return quat.e();
}

int main() {
    std::ofstream outputFile;
    outputFile.open("/home/savanna-runner/Desktop/grf_estimator/data.txt");

    std::ifstream gc_log;
    Eigen::MatrixXd gc_matrix, gv_matrix;
    gc_matrix.setZero(100000,19);
    gv_matrix.setZero(100000,18);

    gc_log.open("/home/savanna-runner/log_data/generalized_position.txt");
    for (size_t i = 0; i < 100000; ++i){
        for (size_t j = 0; j < 19; ++j){
            gc_log >> gc_matrix(i,j);
        }
    }
    gc_log.close();

    raisim::World world_;
    world_.addGround();

//    Eigen::VectorXd g;
//    g.setZero(3,1);
//    g << 0,0,0;
//    world_.setGravity(g);

    raisim::RaisimServer server(&world_);

    std::string resourceDir_;
    resourceDir_ = "/home/savanna-runner/Desktop/grf_estimator/urdf";
    auto robot_ = world_.addArticulatedSystem(resourceDir_+"/HoundOne_generated.urdf");

    YAML::Node cfg_ = YAML::LoadFile("/home/savanna-runner/Desktop/grf_estimator/cfg.yaml");

    Eigen::VectorXd gc,gv;
    gc.setZero(19);
    gv.setZero(18);
//    gc << 0,0,1,1,0,0,0,0,0,2,0,0,2,0,0,0,0,0,2;
    gc << 0,0,0.7,1,0,0,0,0,0.5,-1,0,0.5,-1,0,0.5,-1,0,0.5,-1;
//    gc << 0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;
    gv << 0,0,-5,1,-2,0.5,0,1,-2,0,1,-2,0,1,-2,0,1,-2;

    robot_->setState(gc, gv);
    world_.setTimeStep(0.0001);

    Eigen::VectorXd tau;
    tau.setZero(18);
    tau << 0,0,0,0,0,0,0,-10,10,0,-10,10,0,-10,10,0,-10,10;

    server.launchServer();

    outputFile.is_open();
    std::this_thread::sleep_for(std::chrono::milliseconds (1000));

    std::vector<raisim::Visuals*> points;
    points.push_back(server.addVisualSphere("point1",0.07,1,0,0,0.7));
    points.push_back(server.addVisualSphere("point2",0.07,0,1,0,0.7));
    points.push_back(server.addVisualSphere("point3",0.07,0,0,1,0.7));
    points.push_back(server.addVisualSphere("point4",0.07,1,1,0,0.7));

    std::vector<raisim::Visuals*> forces;
    forces.push_back(server.addVisualArrow("force1", 0.50, 1, 1, 0, 0, 0.7));
    forces.push_back(server.addVisualArrow("force2", 0.050, 0.100, 0, 1, 0, 0.7));
    forces.push_back(server.addVisualArrow("force3", 0.050, 0.100, 0, 0, 1, 0.7));
    forces.push_back(server.addVisualArrow("force4", 0.050, 0.100, 1, 1, 0, 0.7));

    std::vector<Eigen::Vector3d> contact_force(4, Eigen::Vector3d::Zero());
    std::vector<Eigen::Vector3d> contact_force_est(4, Eigen::Vector3d::Zero());
    std::vector<Eigen::Vector3d> contact_point(4, Eigen::Vector3d::Zero());

    Eigen::Vector4d qtn_force;

    Eigen::VectorXd p, p_pre, p_dot;
    Eigen::VectorXd q_dot, q_dot_pre, ga;
    Eigen::VectorXd b;
    Eigen::MatrixXd M, M_pre, M_dot;
    Eigen::VectorXd tau_d, tau_d_est;
    Eigen::VectorXd r, r_pre;
    Eigen::VectorXd sum;

    p.setZero(18);
    p_pre.setZero(18);
    p_dot.setZero(18);

    q_dot.setZero(18);
    q_dot_pre.setZero(18);
    ga.setZero(18);

    b.setZero(18);

    M.setZero(18, 18);
    M_pre.setZero(18, 18);
    M_dot.setZero(18, 18);

    tau_d.setZero(18);
    tau_d_est.setZero(18);
    r.setZero(18);
    r_pre.setZero(18);

    sum.setZero(18);

    double Ki = 1000;

    std::vector<Eigen::MatrixXd> Selector(4,Eigen::MatrixXd::Zero(3,18));
    Selector[0] << Eigen::MatrixXd::Zero(3,6), Eigen::MatrixXd::Identity(3,3), Eigen::MatrixXd::Zero(3,9);
    Selector[1] << Eigen::MatrixXd::Zero(3,9), Eigen::MatrixXd::Identity(3,3), Eigen::MatrixXd::Zero(3,6);
    Selector[2] << Eigen::MatrixXd::Zero(3,12), Eigen::MatrixXd::Identity(3,3), Eigen::MatrixXd::Zero(3,3);
    Selector[3] << Eigen::MatrixXd::Zero(3,15), Eigen::MatrixXd::Identity(3,3);

    std::vector<Eigen::MatrixXd> J_foot(4, Eigen::MatrixXd::Zero(3,18));

    double dt = 0.0001;

//    Eigen::Vector3d force_test;
//    force_test.setZero();
//    force_test << 0,0,10;
//
//    Eigen::Vector3d point_body;
//    point_body.setZero();
//    point_body << 0,0,-0.35;

//    std::vector<raisim::Vec<3>> footPos_(4, Eigen::Vector3d::Zero(3,1));
//    robot_->getFramePosition("RR_foot_fixed", footPos_[0]);



    int index_contact;
    for (int i = 0; i<10000; ++i){
        //robot_->setExternalForce("RR_foot_fixed", force_test);
        //robot_->setExternalForce(3,point_body, force_test);

        world_.integrate();
        robot_->setGeneralizedForce(tau);

        for (auto contact :robot_->getContacts()){
            switch (contact.getlocalBodyIndex()){
                case 3:
                    index_contact = 0;
                    break;
                case 6:
                    index_contact = 1;
                    break;
                case 9:
                    index_contact = 2;
                    break;
                case 12:
                    index_contact = 3;
                    break;
            }
//            std::cout << contact.getlocalBodyIndex() << std::endl;

            points[index_contact]->setPosition(contact.getPosition().e());
            contact_point[index_contact] = contact.getPosition().e();
            contact_force[index_contact] = -contact.getContactFrame().e().transpose()*contact.getImpulse().e()/world_.getTimeStep();

            forces[index_contact]->setPosition(contact.getPosition().e());
            forces[index_contact]->setOrientation(quaternionFromDirectionVector(contact_force[index_contact]));
            forces[index_contact]->setCylinderSize(0.30, contact_force[index_contact].norm()*0.10);
        }

        q_dot = robot_->getGeneralizedVelocity().e();
        ga = (q_dot-q_dot_pre)/ dt;
        b = robot_->getNonlinearities(world_.getGravity()).e();
        M = robot_->getMassMatrix().e();
        p = M*q_dot;
        M_dot = (M-M_pre)/dt;

        r = (r_pre+Ki*(p-p_pre+dt*(-M_dot*q_dot+b-tau)))/(1+Ki*dt); // residual(tau_d) with LPF.

        r_pre = r;
        M_pre = M;
        p_pre = p;
        q_dot_pre = q_dot;

        tau_d = M*ga+b-tau;

//        robot_->getDenseFrameJacobian("RR_foot_fixed", J_foot[0]);
//        robot_->getDenseFrameJacobian("RL_foot_fixed", J_foot[1]);
//        robot_->getDenseFrameJacobian("FR_foot_fixed", J_foot[2]);
//        robot_->getDenseFrameJacobian("FL_foot_fixed", J_foot[3]);
// foot center point jacobian. Not the actual contact point. Actual contact point is on the foot sphere.

        robot_->getDenseJacobian(3, contact_point[0], J_foot[0]);
        robot_->getDenseJacobian(6, contact_point[1], J_foot[1]);
        robot_->getDenseJacobian(9, contact_point[2], J_foot[2]);
        robot_->getDenseJacobian(12, contact_point[3], J_foot[3]);
// foot contact point jacobian.

        for (int i = 0; i<4; ++i){
            contact_force_est[i] = (Selector[i]*J_foot[i].transpose()).inverse()*Selector[i]*tau_d;
        }

        std::cout << "contact_force[0]" << std::endl;
        std::cout << contact_force[0]-contact_force_est[0] << std::endl;
        std::cout << "contact_force[1]" << std::endl;
        std::cout << contact_force[1]-contact_force_est[1] << std::endl;
        std::cout << "contact_force[2]" << std::endl;
        std::cout << contact_force[2]-contact_force_est[2] << std::endl;
        std::cout << "contact_force[3]" << std::endl;
        std::cout << contact_force[3]-contact_force_est[3] << std::endl;


//        std::cout << "J_foot[0]" << std::endl;
//        std::cout << J_foot[0] << std::endl;

        tau_d_est = J_foot[0].transpose()*contact_force[0]
                +J_foot[1].transpose()*contact_force[1]
                +J_foot[2].transpose()*contact_force[2]
                +J_foot[3].transpose()*contact_force[3];

//        tau_d_est = J_foot[0].transpose()*force_test;

        Eigen::MatrixXd tau_concat;
        tau_concat.setZero(18,3);
        tau_concat << tau_d, tau_d_est, r;

//        std::cout << "tau comparison" << std::endl;
//        std::cout << tau_concat.transpose() << std::endl;
//        std::cout << "J_foot[0]" << std::endl;
//        std::cout << J_foot[0] << std::endl;

        std::this_thread::sleep_for(std::chrono::milliseconds (10));
    }
      server.killServer();
    outputFile.close();
    std::cout << "simulation ended" << std::endl;
    return 0;

}